package com.cg.appl.daos;


import java.util.List;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;

public interface IHotelDao {
	
	List<Hotel> showAllHotel() throws BookingException;
	Hotel getHotel(String hotelID) throws BookingException;
	
	
	Users isUserAuthenticated(String userName, String password) throws BookingException;
	
	Users getUserDetails(String userName) throws BookingException;
	
	String getUserDetailsOld(String userName) throws BookingException;
	
	int AddHotel(Hotel hotel) throws BookingException;
	boolean deleteHotel(String hotel_id) throws BookingException;
	boolean updateHotel(Hotel hotel) throws BookingException;
	String addbook(BookingDetails book) throws BookingException;
	List<RoomDetails> showAllRooms(String hotel_id) throws BookingException;
	RoomDetails showRoom(String hotel_id, String room_id) throws BookingException;
	
	List<RoomDetails> checkAvailability(String hotelId)  throws BookingException;
	
	List<Hotel> GetHotelNames() throws BookingException;
	 String GetHotelName(String hotelID) throws BookingException;
	 
	 String addRoom(RoomDetails room) throws BookingException;
	 boolean deleterooms(String room_id) throws BookingException;
	 
	 boolean updateRoom(RoomDetails room, String hotel_id) throws BookingException;
	 
	 List<BookingDetails> viewHotelwiseBooking(String hotel_id) throws BookingException;
	 
	 Users getUserDetailsForReport(String UserID) throws BookingException;
	 
	 List<BookingDetails> viewBookingDatewise(String fromDate, String toDate) throws BookingException;
	 
	 String addUser(Users user) throws BookingException;
	List<Users> viewGuestList(String user_id) throws BookingException;
}
