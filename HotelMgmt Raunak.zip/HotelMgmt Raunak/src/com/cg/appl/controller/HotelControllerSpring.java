package com.cg.appl.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;
import com.cg.appl.services.HotelServicesImpl;
import com.cg.appl.services.IHotelServices;


@Controller
@SessionAttributes({"userID","roomDetails","roomId","roomIDForRoomUpdate","roomType","fromDate","toDate","noOfRooms","noOfAdults","noOfChildren","hotelIDForUpdate","oprStatus","oprStatusFailed","rooms","deleteException","hotel","updateHotelIDInvalid","list","bookingList","dateErrorForHotelwiseBooking"})
public class HotelControllerSpring {


	private IHotelServices services;
	
	@PostConstruct
	public void initialize(){
		ModelAndView model=new ModelAndView();
	}
    @Resource(name="hotelService")
	public void setServices(HotelServicesImpl services) {
		this.services = services;
	}
    @RequestMapping("/welcome.do")
    public ModelAndView welcome(){
    	Users user=new Users();
    	ModelAndView model=new ModelAndView("Register.jsp");
    	model.addObject("user",user);
    	return model;
    	
    }
    
    @RequestMapping("/registerNewUser.do")
    public ModelAndView registerNewUser(@ModelAttribute @Valid Users user,BindingResult result){
    	ModelAndView model=new ModelAndView();
		try {
			String uName = services.addUser(user);
			if(result.hasErrors()){
				System.out.println(result.getAllErrors());
				model.addObject("user",user);
				model.setViewName("index.jsp");
				return model;
				
			}		
			if(uName.equals(user.getUser_name()))
				{
					model.addObject("oprStatus", "User "+uName+" is Registered to system !!!");					
				}
			else
				{
				    model.addObject("oprStatusFailed", "Unable to register New User "+uName);
				}
			model.setViewName("Register.jsp");
		} catch (BookingException e) {
			e.printStackTrace();
		}
    	return model;
    }
    
    @RequestMapping("/authenticate.do")
    public ModelAndView authenticate(@ModelAttribute Users user,HttpServletRequest request, HttpSession session){
    	ModelAndView model=new ModelAndView();
		
		try {
			Users authenticatedUser = services.isUserAuthenticated(user.getUser_name(),user.getPassword());
			if(!authenticatedUser.getUser_id().equals("error"))
			{
				System.out.println("Yes");
										
				//code for starting new session

				session = request.getSession(true);
		
				String UserRole = authenticatedUser.getRole();
				if(UserRole.equals("Customer")||UserRole.equals("HotelEmp")||UserRole.equals("n/a"))
				{
					model.addObject("userID",authenticatedUser.getUser_id());
					//session.setAttribute("userID",authenticatedUser.getUser_id());
					model.setViewName("showCustomerMenu.do");
					//nextJsp = "showCustomerMenu.do";
				}
				else if(UserRole.equals("Admin"))
				{
					model.addObject("userID",authenticatedUser.getUser_id());
					//session.setAttribute("userID",authenticatedUser.getUser_id());
					model.setViewName("showAdminMenu.do");
					//nextJsp = "showAdminMenu.do";
				}
				
			}
			else
			{
				System.out.println("No");
				
				String message = "Wrong Credentials Entered !!!";
				
				model.addObject("errorMsg",message);
				//request.setAttribute("errorMsg", message);
				//ctx.log("error Message : "+message);
				model.setViewName("/index.jsp");
				//nextJsp = "/index.jsp";
			}
			
		} catch (BookingException e) {
			
			/*dispatch = request.getRequestDispatcher("/error.jsp");
			dispatch.forward(request, response);*/
			model.setViewName("/index.jsp");
			//nextJsp = "/index.jsp";
			System.out.println(e);
			//ctx.log(e.getMessage());
			String message = "User Name does not exist !!!";
			model.addObject("errorMsg",message);
			//request.setAttribute("errorMsg", message);
		}
    	return model;
    }
    
    @RequestMapping("/showAdminMenu.do")
    public ModelAndView showAdminMenu(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		List<Hotel> hotelList = services.showAllHotel();
 	    model.addObject("list", hotelList);
 		model.setViewName("/adminMenu.jsp");
 		//nextJsp = "/adminMenu.jsp";
    	return model;
    }
    
    @RequestMapping("/showAddRoom.do")
    public ModelAndView showAddRoom(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("show add room user Id : "+user_id);
 		
 		List<Hotel> list = services.showAllHotel();
 		model.addObject("list", list);
 		RoomDetails room=new RoomDetails();
 		model.addObject("room",room);
 		model.setViewName("/addRoom.jsp");
 		//nextJsp = "/addRoom.jsp";
    	return model;
    }
    
    @RequestMapping("/addRoom.do")
    public ModelAndView addRoom(@ModelAttribute @Valid RoomDetails room,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("add room user Id : "+user_id);
 		
 		//RoomDetails room = new RoomDetails();
 		room.setAvailability(1);
 		//room.setHotel_id(hotelName);
 		/*room.setPer_night_rate(room.getPer_night_rate());
 		room.setRoom_no((room.getRoom_no()));
 		room.setRoom_type(room.getRoom_type());*/
 		
 		String roomID = services.addRoom(room);
 		
 		model.addObject("oprStatus","Room: "+roomID+" is added successfully to Hotel "+services.GetHotelName(room.getHotel_id()));
 		model.setViewName("/adminMenu.jsp");
 		//nextJsp = "/adminMenu.jsp";
    	return model;
    }
    
    @RequestMapping("/showUpdateRoom.do")
    public ModelAndView showUpdateRoom(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("roomDetailsForUpdate user Id : "+user_id);
 		model.setViewName("/updateRoom.jsp");
 		//nextJsp = "/updateRoom.jsp";
    	return model;
    }
    
    @RequestMapping("/showNPopulateUpdateRoom.do")
    public ModelAndView showNPopulateUpdateRoom(@RequestParam String hotelId,@RequestParam String roomId,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("show update room user Id : "+user_id);
 		
 		//String hotelID = request.getParameter("hotelid);
 		//String roomID = request.getParameter("roomID");
 		
 		model.addObject("hotelIDForUpdate",hotelId);
 		//session.setAttribute("hotelIDForUpdate", hotelId);
 		
 		RoomDetails room = services.showRoom(hotelId, roomId);
 		System.out.println();
 		if(room.getRoom_type()==null)
 		{
 			session.setAttribute("oprStatusUpdateRoom","Room id/Hotel id does not exist ");
 			model.setViewName("/updateRoom.jsp");
 			//nextJsp = "/updateRoom.jsp";
 		}
 		else
 		{ 
 			model.addObject("roomDetails",room);
 			model.addObject("roomID", roomId);
 			model.addObject("roomIDForRoomUpdate", roomId);
 			model.addObject("roomType",room.getRoom_type());
 			/*session.setAttribute("roomDetails", room);
 			session.setAttribute("roomID", roomID);
 			session.setAttribute("roomIDForRoomUpdate", roomID);
 			session.setAttribute("roomType",room.getRoom_type());*/
 			model.setViewName("/updatePopulateRoom.jsp");
 			//nextJsp = "/updatePopulateRoom.jsp";
 		}
 		
 		
    	return model;
    }
    
    @RequestMapping("/updateRoom.do")
    public ModelAndView updateRoom(@ModelAttribute RoomDetails room,@RequestParam String roomTypeOld,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("update room user Id : "+user_id);
 		
 		//RoomDetails room = new RoomDetails();
 		room.setAvailability(1);
 		//room.setHotel_id(request.getParameter("hotelName"));
 		//room.setPer_night_rate(Integer.parseInt(request.getParameter("roomPrice")));
 		//room.setRoom_no((request.getParameter("roomNo")));
 		
 		if(request.getParameter("roomType").equals("blank"))
 		{
 			room.setRoom_type(roomTypeOld);
 		}
 
 		System.out.println(room.getRoom_type());
 		
 		room.setRoom_id(session.getAttribute("roomIDForRoomUpdate").toString());
 		
 		boolean isUpdated = services.updateRoom(room, session.getAttribute("hotelIDForUpdate").toString());
 		
 		if(isUpdated)
 		{
 			session.setAttribute("oprStatus","Room: "+session.getAttribute("roomID")+" is updated successfully for Hotel "+services.GetHotelName(session.getAttribute("hotelIDForUpdate").toString()));
 		}
 		else
 		{
 			session.setAttribute("oprStatusFailed","Room: "+session.getAttribute("roomID")+" is Unable to update for Hotel "+services.GetHotelName(session.getAttribute("hotelIDForUpdate").toString()));
 		}
 		model.setViewName("/adminMenu.jsp");
 		//nextJsp = "/adminMenu.jsp";
    	return model;
    }
    
    @RequestMapping("/showDeleteRoom.do")
    public ModelAndView showDeleteRoom(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("show Delete room user Id : "+user_id);
 		model.setViewName("/deleteRoom.jsp");
 		//nextJsp = "/deleteRoom.jsp";
    	return model;
    }
    
    @RequestMapping("/deleteRoom.do")
    public ModelAndView deleteRoom(@RequestParam String hotelName,@RequestParam String roomId,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
 		String hotelID = hotelName;
 		String roomID = roomId; 		
 		System.out.println("roonID " +roomID);

 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("delete room user Id : "+user_id);
 			 		
 		boolean isDeleted = services.deleterooms(roomID);
 		
 		if(isDeleted)
 		{
 			session.setAttribute("oprStatus", "Room "+roomID+"is Deleted successfully from Hotel "+services.GetHotelName(hotelID));
 			model.setViewName("/adminMenu.jsp");
 			//nextJsp = "/adminMenu.jsp";
 		}
 		else
 		{
 			session.setAttribute("deleteException","Invalid Room ID : "+roomID);
 			model.setViewName("/deleteRoom.jsp");
 			//nextJsp = "/deleteRoom.jsp";
 		}
    	return model;
    }
    
    @RequestMapping("/showAddHotel.do")
    public ModelAndView showAddHotel(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		model.setViewName("/addHotel.jsp");
 		//nextJsp = "/addHotel.jsp";
    	return model;
    }
    
    @RequestMapping("/addHotel.do")
    public ModelAndView addHotel(@ModelAttribute Hotel hotel,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();		
		HttpSession session = request.getSession(false);
		/*String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
		String hotelName =  request.getParameter("hotelName");
		hotel.setHotel_name(hotelName);
		String city = request.getParameter("hotelCity");
		hotel.setCity(city);
		String address = request.getParameter("address");
		hotel.setAddress(address);
		String desc = request.getParameter("desc");
		hotel.setDescription(desc);
		int price =Integer.parseInt(request.getParameter("price"));
		hotel.setAvg_rate_per_night(price);
		String contact1 = request.getParameter("phno");
		hotel.setPhone_no1(contact1);
		String contact2 = request.getParameter("phno2");
		hotel.setPhone_no2(contact2);
		int rating =Integer.parseInt(request.getParameter("rate"));
		hotel.setRating(rating);
		String email =request.getParameter("email");
		hotel.setEmail(email);
		String fax =request.getParameter("fax");
		hotel.setFax(fax);*/
						
		int count =services.AddHotel(hotel);
		if(count >= 1)
		{
			System.out.println("hotel added !!!");
			model.addObject("hotel", hotel);
		}
		else
		{
			String message = "Unable to add new hotel !!!";
			model.addObject("errorMsg", message);
			//ctx.log("error Message : "+message);
			model.setViewName("/addHotel.jsp");
			//nextJsp = "/addHotel.jsp";
		}
    	return model;
    }
    
    @RequestMapping("/showUpdateHotel.do")
    public ModelAndView showUpdateHotel(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
 		model.setViewName("/updateHotel.jsp");
    	//nextJsp = "/updateHotel.jsp";
    	return model;
    }
    
    @RequestMapping("/populateUpdateHotel.do")
    public ModelAndView populateUpdateHotel(@RequestParam String hotelID,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
 		//getting hotel id from form
 		//String hotelID = request.getParameter("hotelID");
 		//getting hotel details from dao
 		Hotel hotel = new Hotel();		 		
 		
 		hotel = services.getHotel(hotelID);
 		
 		if(hotel==null)
 		{
 			session.setAttribute("updateHotelIDInvalid", "Invalid Hotel ID !!!");
 			model.setViewName("/updateHotel.jsp");
/* 			nextJsp = "/updateHotel.jsp";
 			dispatch = request.getRequestDispatcher(nextJsp);
			dispatch.forward(request,response);*/
 		}
 		else
 		{
 			session.setAttribute("hotel", hotel);
 			//setting attribute of session for populating form
 			model.setViewName("/updateHotel.jsp");
	 		//nextJsp="/updateHotel.jsp";
 		}
    	return model;
    }
    
    @RequestMapping("/updateHotel.do")
    public ModelAndView updateHotel(@ModelAttribute Hotel hotel,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	System.out.println("In Update Hotel.do");
 		HttpSession session = request.getSession(false);
 		
 		//Hotel hotel = new Hotel();
 	/*	String hotelID = request.getParameter("hotelID2").toString();
 		hotel.setHotel_id(hotelID);
 		String hotelName = request.getParameter("updateHotelName").toString();
 		hotel.setHotel_name(hotelName);
 		String description = request.getParameter("description").toString();
 		hotel.setDescription(description);
 		int price = Integer.parseInt(request.getParameter("price"));
 		hotel.setAvg_rate_per_night(price);
 		String phno1 = request.getParameter("phno1").toString();
 		hotel.setPhone_no1(phno1);
 		String phno2 = request.getParameter("phno2").toString();
 		hotel.setPhone_no2(phno2);
 		int rating = Integer.parseInt(request.getParameter("rating"));
 		hotel.setRating(rating);
 		String email = request.getParameter("email").toString();
 		hotel.setEmail(email);
 		String fax = request.getParameter("fax").toString();
 		hotel.setFax(fax);*/
 		
 		boolean isUpdated = services.updateHotel(hotel);
 		System.out.println(isUpdated);
 		if(isUpdated)
 		{
 			model.setViewName("/adminMenu.jsp");
 			//nextJsp="/adminMenu.jsp";
 		}
 		else
 		{		 		
 			model.setViewName("/adminMenu.jsp");
 			//nextJsp="/updateHotel.jsp";
 			String message = "Unable to update Hotel !!!";
 			session.setAttribute("errorMsg", message);
 		}
    	return model;
    }
    
    @RequestMapping("/delete.do")
    public ModelAndView delete(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	System.out.println("In delete.do");
	 	
	 	HttpSession session = request.getSession(false);
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		model.setViewName("/deleteHotel.jsp");
		//nextJsp = "/deleteHotel.jsp";
    	return model;
    }
    
    @RequestMapping("/deleteHotel.do")
    public ModelAndView deleteHotel(@RequestParam String hotelId,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	 System.out.println("In deleteHotel.do");
		 //String hotelId=request.getParameter("hotelId");
		 boolean flag=services.deleteHotel(hotelId);
		 if(flag)
		 {
			 System.out.println("Deleted Hotel Successfully");
			 //nextJsp="/deleteHotel.jsp";
		 }
		 else
		 {
			 System.out.println("Hotel Not Deleted");
			 model.addObject("errorMsg","Unable To delete");
			
			 //nextJsp="/deleteHotel.jsp";
		 }		
		 model.setViewName("/deleteHotel.jsp");
    	return model;
    }
    
    @RequestMapping("/showReportsMenu.do")
    public ModelAndView showReportsMenu(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		model.setViewName("/reportsMenu.jsp");
 		//nextJsp = "/reportsMenu.jsp";
    	return model;
    }
    
    
    @RequestMapping("/showHotels.do")
    public ModelAndView showHotels(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		
 		List<Hotel> hotelList = services.showAllHotel();
 		session.setAttribute("list", hotelList);
 		model.setViewName("/HotelListReport.jsp");
 		//nextJsp = "/HotelListReport.jsp";
    	return model;
    }
    
    @RequestMapping("/getHotelIDForReport.do")
    public ModelAndView getHotelIDForReport(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();

 		HttpSession session = request.getSession(false);
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		model.setViewName("/hotelIDForReport.jsp");	 		
 		//nextJsp = "/hotelIDForReport.jsp";
    	return model;
    }
    
    @RequestMapping("/showHotelwiseBooking.do")
    public ModelAndView showHotelwiseBooking(@RequestParam String hotelID,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);		 		

 		List<BookingDetails> bookingList = services.viewHotelwiseBooking(hotelID);
 		
 		for(BookingDetails index : bookingList)
 		{
 			index.setUser(services.getUserDetailsForReport(index.getUser_id()));
 		}
 		if(bookingList.isEmpty())
 		{
 			session.setAttribute("dateErrorForHotelwiseBooking","Hotel ID does not exist !!!");
 			model.setViewName("/acceptHotelIdForReport.jsp");	
 			/*nextJsp = "/acceptHotelIdForReport.jsp";
 			dispatch = request.getRequestDispatcher(nextJsp);
			dispatch.forward(request,response);*/
 		}
 		else
 		{
 			session.setAttribute("bookingList", bookingList);		 
 			model.setViewName("/BookingListReport.jsp");	
 	/*		nextJsp = "/BookingListReport.jsp";
	 		dispatch = request.getRequestDispatcher(nextJsp);
			dispatch.forward(request,response);	 		*/	
 		}
    	return model;
    }
    
    @RequestMapping("/getHotelIDForGuestListReport.do")
    public ModelAndView getHotelIDForGuestListReport(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		model.setViewName("/acceptHotelIdForReport.jsp"); 		
 		//nextJsp = "/acceptHotelIdForReport.jsp";
    	return model;
    }
    
    @RequestMapping("/showHotelwiseUsers.do")
    public ModelAndView showHotelwiseUsers(@RequestParam String hotelID,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 				 		
 		//String hotelID = request.getParameter("hid");
 		
 		List<BookingDetails> bookingList = services.viewHotelwiseBooking(hotelID);
 		
 		for(BookingDetails index : bookingList)
 		{
 			index.setUser(services.getUserDetailsForReport(index.getUser_id()));
 		}
 		
 		if(bookingList.isEmpty())
 		{
 			session.setAttribute("dateErrorForHotelwiseBooking","Hotel ID does not exist !!!");
 			model.setViewName("/acceptHotelIdForReport.jsp");
 			/*nextJsp = "/acceptHotelIdForReport.jsp";
 			dispatch = request.getRequestDispatcher(nextJsp);
			dispatch.forward(request,response);*/
 		}
 		else
 		{
 		
	 		session.setAttribute("bookingList", bookingList);	
	 		model.setViewName("/GuestListReport.jsp");
	 	/*	nextJsp = "/GuestListReport.jsp";
	 		dispatch = request.getRequestDispatcher(nextJsp);
			dispatch.forward(request,response);*/
 		}
    	return model;
    }
    
    @RequestMapping("/getDatesForReport.do")
    public ModelAndView getDatesForReport(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		model.setViewName("/specifiedDateReport.jsp");	 		
 		//nextJsp = "/specifiedDateReport.jsp";
    	return model;
    }
    
    @RequestMapping("/showDatewiseBooking.do")
    public ModelAndView showDatewiseBooking(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		String hotelID= request.getParameter("hotelid");
 		String fromDate = request.getParameter("from");
 		String toDate = request.getParameter("to");
 		//#####################################
 		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date datefrom = sdf.parse(request.getParameter("from"));
			Date dateto = sdf.parse(request.getParameter("to"));
			 Date sysdate = new Date();

			if (dateto.before(datefrom)) {
			    System.out.println("Date1 is before Date2");
			    session.setAttribute("dateErrorForDateReport","check-in date must be before check-out Date");
			   /* dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
				dispatch.forward(request,response);*/
			} else
				if (datefrom.equals(dateto)) {
			    System.out.println("Date1 is equal to Date2");
			    session.setAttribute("dateErrorForDateReport","check-in date must be different from check-out Date");
			   /* dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
				dispatch.forward(request,response);*/
			}
			else
						if (dateto.before(sysdate)||datefrom.before(sysdate)) {
					    System.out.println("Date1 is equal to Date2");
					    session.setAttribute("dateErrorForDateReport","check-in /check-out date cannot be before today");
					   /* dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
						dispatch.forward(request,response);*/
			}else 
						if (dateto.after(datefrom)) {
					    System.out.println("Date1 is after Date2");
					    List<BookingDetails> bookingList = services.viewBookingDatewise(fromDate, toDate);	 		
				 		
					    if(bookingList.isEmpty())
					    {
					    	session.setAttribute("dateErrorForDateReport","Hotel ID does not exist !!!");
						   /* dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
							dispatch.forward(request,response);*/
					    }else
					    {
					    
					 		session.setAttribute("bookingList",bookingList);
					 		
					 	/*	nextJsp="/dateReport.jsp";
					 		
						    dispatch = request.getRequestDispatcher(nextJsp);
							dispatch.forward(request,response);*/
					    }
					}
			
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
    	return model;
    }
    
    @RequestMapping("/showCustomerMenu.do")
    public ModelAndView showCustomerMenu(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		
 		List<Hotel> list = services.showAllHotel();
 		session.setAttribute("list", list);
 		
 		System.out.println(list);
 		model.setViewName("/book.jsp");
 		//nextJsp = "/book.jsp";
    	return model;
    }
    
    @RequestMapping("/showBookingStatus.do")
    public ModelAndView showBookingStatus(){
    	ModelAndView model=new ModelAndView();
    	return model;
    }
    
    @RequestMapping("/booking.do")
    public ModelAndView booking(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
	 	
	    String  user_id  = session.getAttribute("userID").toString();
        System.out.println(user_id);

        System.out.println("In booking.do");
        model.setViewName("/book.jsp"); 
        //nextJsp = "/book.jsp";
    	return model;
    }
    
    @RequestMapping("/checkAvailability.do")
    public ModelAndView checkAvailability(@RequestParam int no_of_rooms,@ModelAttribute BookingDetails book,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	 HttpSession session = request.getSession(false);

	 	 String  user_id  = session.getAttribute("userID").toString();
 		System.out.println(user_id);
	 
 		String hotelID = request.getParameter("hotelName").toString();
 		Hotel hotel = new Hotel();
 		hotel.setHotel_id(hotelID);
 		
 		session.setAttribute("hotelName", services.GetHotelName(hotelID));
 		
 		session.setAttribute("fromDate", book.getBooked_from());
 		session.setAttribute("toDate", book.getBooked_to());
 		
 		session.setAttribute("noOfRooms",no_of_rooms);
 		session.setAttribute("noOfAdults",book.getNo_of_adults());
 		session.setAttribute("noOfChildren",book.getNo_of_children());
 		
 		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date datefrom = sdf.parse(request.getParameter("from"));
			Date dateto = sdf.parse(request.getParameter("to"));
			 Date sysdate = new Date();

			if (dateto.before(datefrom)) {
			    System.out.println("Date1 is before Date2");
			    session.setAttribute("dateError","check-in date must be before check-out Date");
			   /* dispatch = request.getRequestDispatcher("booking.do");
				dispatch.forward(request,response);*/
			} else
				if (datefrom.equals(dateto)) {
			    System.out.println("Date1 is equal to Date2");
			    session.setAttribute("dateError","check-in date must be different from check-out Date");
			    /*dispatch = request.getRequestDispatcher("booking.do");
				dispatch.forward(request,response);*/
			}
			else
						if (dateto.before(sysdate)||datefrom.before(sysdate)) {
					    System.out.println("Date1 is equal to Date2");
					    session.setAttribute("dateError","check-in /check-out date cannot be before today");
					/*    dispatch = request.getRequestDispatcher("booking.do");
						dispatch.forward(request,response);*/
			}else 
						if (dateto.after(datefrom)) {
					    System.out.println("Date1 is after Date2");
					    List<RoomDetails> rooms = services.checkAvailability(hotel.getHotel_id());					 		
				 		session.setAttribute("RoomList", rooms);
					    /*dispatch = request.getRequestDispatcher("/roomDetails.jsp");
						dispatch.forward(request,response);*/
					}
			
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
 		
 		List<RoomDetails> rooms = services.checkAvailability(hotel.getHotel_id());
 		
 		session.setAttribute("RoomList", rooms);							
 		model.setViewName("/roomDetails.jsp");
 		//nextJsp = "/roomDetails.jsp";
	 	
    	return model;
    }
    
    @RequestMapping("/bookHotelRoom.do")
    public ModelAndView bookHotelRoom(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
 		String  room_no  = request.getParameter("rno");
 		System.out.println(room_no);
 		
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println(user_id);
 		
 		BookingDetails bookingDetails = new BookingDetails();
 		
 		bookingDetails.setUser_id(session.getAttribute("userID").toString());
 		bookingDetails.setRoom_id(request.getParameter("id").toString());
 		bookingDetails.setNo_of_adults(Integer.parseInt(session.getAttribute("noOfAdults").toString()));
 		bookingDetails.setNo_of_children(Integer.parseInt(session.getAttribute("noOfChildren").toString()));
 		
 		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate fromDate  = LocalDate.parse(session.getAttribute("fromDate").toString(),formatter);
		java.util.Date utilFromDate;
		try {
			utilFromDate = new SimpleDateFormat("yyyy-MM-dd").parse(fromDate.toString());
			bookingDetails.setBooked_from(utilFromDate);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
 		
 		
		LocalDate toDate  = LocalDate.parse(session.getAttribute("toDate").toString(),formatter);
		java.util.Date utilToDate;
		try {
			utilToDate = new SimpleDateFormat("yyyy-MM-dd").parse(toDate.toString());
			bookingDetails.setBooked_to(utilToDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Period period = fromDate.until(toDate);
		int days  = period.getDays();
 		int amount = (Integer.parseInt(request.getParameter("price"))*days);
 		
 		bookingDetails.setAmount(amount);
 		
 		System.out.println(bookingDetails);
 		
 		String bookingID = services.addbook(bookingDetails);
 		
 		System.out.println(bookingID);
 		session.setAttribute("roomNo", room_no);
 		session.setAttribute("id", bookingID);
 		//nextJsp = "/success.jsp";
 		
    	return model;
    }
    
    @RequestMapping("/showRoomDetails.do")
    public ModelAndView showRoomDetails(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);	
	 	List<RoomDetails> rooms = services.showAllRooms("1103");
	 	session.setAttribute("rooms", rooms);
	 	model.setViewName("/roomDetails.jsp");
		//nextJsp = "/roomDetails.jsp";
    	return model;
    }
    @RequestMapping("/logout.do")
    public ModelAndView logout(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
		session.invalidate(); //destroying session
		model.setViewName("/index.jsp");
		//nextJsp = "/index.jsp";
    	return model;
    }
    

}
