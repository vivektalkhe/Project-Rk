package com.cg.appl.services;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.appl.daos.HotelDaoImpl;
import com.cg.appl.daos.IHotelDao;
import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;

@Service("hotelServices")
@Transactional
public class HotelServicesImpl implements IHotelServices{

private IHotelDao dao;
	public HotelServicesImpl(){
		dao = new HotelDaoImpl(); 
	}
	@Override
	public Users isUserAuthenticated(String userName, String password)
			throws BookingException {
		return dao.isUserAuthenticated(userName, password);
	}
	@Override
	public boolean deleteHotel(String hotel_id) throws BookingException {
		return dao.deleteHotel(hotel_id);
	}

	@Override
	public boolean updateHotel(Hotel hotel) throws BookingException {
		return dao.updateHotel(hotel);
	}

	@Override
	public int AddHotel(Hotel hotel) throws BookingException {
		return dao.AddHotel(hotel);
	}

	@Override
	public List<Hotel> showAllHotel() throws BookingException {
		
		return dao.showAllHotel();
	}

	@Override
	public String getUserDetailsOld(String userName) throws BookingException {
		
		return dao.getUserDetailsOld(userName);
	}

	@Override
	public List<RoomDetails> showAllRooms(String hotel_id)
			throws BookingException {
		
		return dao.showAllRooms(hotel_id);
	}
	@Override
	public Hotel getHotel(String hotelID) throws BookingException {
		
		return dao.getHotel(hotelID);
	}

	@Override
	public List<RoomDetails> checkAvailability(String hotelId)
			throws BookingException {
		
		return dao.checkAvailability(hotelId);
	}

	@Override
	public String addbook(BookingDetails book) throws BookingException {
		
		return dao.addbook(book);
	}

	@Override
	public String GetHotelName(String hotelID) throws BookingException {
		
		return dao.GetHotelName(hotelID);
	}

	@Override
	public String addRoom(RoomDetails room) throws BookingException {
		
		return dao.addRoom(room);
	}

	@Override
	public boolean deleterooms(String room_id) throws BookingException {
		
		return dao.deleterooms(room_id);
	}

	@Override
	public boolean updateRoom(RoomDetails room, String hotel_id) throws BookingException {
		
		return dao.updateRoom(room,hotel_id);
	}

	@Override
	public RoomDetails showRoom(String hotel_id, String room_id)
			throws BookingException {
		
		return dao.showRoom(hotel_id, room_id);
	}

	@Override
	public List<BookingDetails> viewHotelwiseBooking(String hotel_id)
			throws BookingException {
		
		return dao.viewHotelwiseBooking(hotel_id);
	}

	@Override
	public Users getUserDetailsForReport(String UserID)
			throws BookingException {
		
		return dao.getUserDetailsForReport(UserID);
	}

	@Override
	public List<BookingDetails> viewBookingDatewise(String fromDate,
			String toDate) throws BookingException {
		
		return dao.viewBookingDatewise(fromDate, toDate);
	}

	@Override
	public String addUser(Users user) throws BookingException {
		
		return dao.addUser(user);
	}

	
}
